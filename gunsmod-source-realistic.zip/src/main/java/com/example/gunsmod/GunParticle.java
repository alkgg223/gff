package com.example.gunsmod;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.core.particles.SimpleParticleType;

/** Realistic gun / explosion particles (soft smoke, muzzle flash, hot sparks, fire, dust). Client only. */
public class GunParticle extends TextureSheetParticle {
    public enum Kind { SMOKE_S, SMOKE_M, SMOKE_L, DUST, FLASH_S, FLASH_L, SPARK, FIRE }

    private final Kind kind;
    private final SpriteSet sprites;
    private final float size0, size1;
    private final float shade;

    protected GunParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz,
                          SpriteSet sprites, Kind kind) {
        super(level, x, y, z);
        this.sprites = sprites;
        this.kind = kind;
        this.xd = vx;
        this.yd = vy;
        this.zd = vz;
        if (kind == Kind.FLASH_S || kind == Kind.FLASH_L) { this.xd = 0; this.yd = 0; this.zd = 0; }
        this.hasPhysics = kind == Kind.SPARK;
        this.pickSprite(sprites);
        this.roll = this.oRoll = this.random.nextFloat() * 6.2831855f;
        float r = this.random.nextFloat();
        this.shade = 0.75f + this.random.nextFloat() * 0.25f;
        switch (kind) {
            case SMOKE_S -> { size0 = 0.07f + r * 0.05f; size1 = 0.28f + r * 0.14f; lifetime = 12 + random.nextInt(10); friction = 0.86f; gravity = -0.01f; }
            case SMOKE_M -> { size0 = 0.25f + r * 0.15f; size1 = 0.9f + r * 0.5f; lifetime = 30 + random.nextInt(25); friction = 0.9f; gravity = -0.012f; }
            case SMOKE_L -> { size0 = 0.8f + r * 0.5f; size1 = 2.6f + r * 1.4f; lifetime = 60 + random.nextInt(50); friction = 0.94f; gravity = -0.02f; }
            case DUST -> { size0 = 0.12f + r * 0.1f; size1 = 0.5f + r * 0.35f; lifetime = 16 + random.nextInt(14); friction = 0.82f; gravity = 0.005f; }
            case FLASH_S -> { size0 = 0.38f + r * 0.18f; size1 = 0.12f; lifetime = 2 + random.nextInt(2); friction = 0.5f; gravity = 0f; }
            case FLASH_L -> { size0 = 3.2f + r; size1 = 0.4f; lifetime = 5 + random.nextInt(3); friction = 0.5f; gravity = 0f; }
            case SPARK -> { size0 = 0.035f + r * 0.03f; size1 = 0.01f; lifetime = 10 + random.nextInt(14); friction = 0.9f; gravity = 0.55f; }
            default -> { size0 = 0.7f + r * 0.5f; size1 = 2.0f + r * 1.0f; lifetime = 14 + random.nextInt(12); friction = 0.9f; gravity = -0.005f; }
        }
        this.quadSize = size0;
        applyLook(0f);
    }

    private void applyLook(float t) {
        switch (kind) {
            case SMOKE_S, SMOKE_M, SMOKE_L -> {
                float g = (kind == Kind.SMOKE_L ? 0.16f : 0.36f) * shade + (kind == Kind.SMOKE_S ? 0.1f * (1f - t) : 0f);
                rCol = g; gCol = g; bCol = g * 1.04f;
                float peak = kind == Kind.SMOKE_L ? 0.8f : 0.55f;
                alpha = peak * (float) Math.pow(1f - t, 1.4) * Math.min(1f, (t + 0.06f) * 8f);
                quadSize = size0 + (size1 - size0) * (float) (1 - Math.pow(1 - t, 2.2));
            }
            case DUST -> {
                rCol = 0.62f * shade; gCol = 0.57f * shade; bCol = 0.49f * shade;
                alpha = 0.5f * (1f - t) * (1f - t);
                quadSize = size0 + (size1 - size0) * (float) (1 - Math.pow(1 - t, 2.0));
            }
            case FLASH_S, FLASH_L -> {
                rCol = 1f; gCol = 0.82f - 0.25f * t; bCol = 0.45f - 0.3f * t;
                alpha = 1f - t * t;
                quadSize = size0 + (size1 - size0) * t;
            }
            case SPARK -> {
                rCol = 1f; gCol = 0.85f - 0.5f * t; bCol = 0.45f - 0.4f * t;
                alpha = 1f - t * t * t;
                quadSize = size0 + (size1 - size0) * t;
            }
            default -> { // FIRE: white-yellow -> orange -> dark red, then fades
                float k = Math.min(1f, t * 1.6f);
                rCol = 1f - 0.25f * k; gCol = 0.9f - 0.65f * k; bCol = 0.5f - 0.45f * k;
                alpha = 0.95f * (1f - (float) Math.pow(t, 1.6));
                quadSize = size0 + (size1 - size0) * (float) Math.sqrt(t);
            }
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (!removed) {
            float t = Math.min(1f, (float) age / (float) lifetime);
            this.oRoll = this.roll;
            if (kind == Kind.SMOKE_S || kind == Kind.SMOKE_M || kind == Kind.SMOKE_L) this.roll += 0.02f * (this.shade - 0.85f);
            applyLook(t);
        }
    }

    @Override
    protected int getLightColor(float partialTick) {
        if (kind == Kind.FLASH_S || kind == Kind.FLASH_L || kind == Kind.SPARK) return LightTexture.FULL_BRIGHT;
        if (kind == Kind.FIRE && age < lifetime * 0.55f) return LightTexture.FULL_BRIGHT;
        return super.getLightColor(partialTick);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        private final Kind kind;

        public Provider(SpriteSet sprites, Kind kind) {
            this.sprites = sprites;
            this.kind = kind;
        }

        @Override
        public net.minecraft.client.particle.Particle createParticle(SimpleParticleType type, ClientLevel level,
                                                                     double x, double y, double z,
                                                                     double xd, double yd, double zd) {
            return new GunParticle(level, x, y, z, xd, yd, zd, sprites, kind);
        }
    }
}
